package com.popupzero

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("pz", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var protectSwitch: Switch
    private lateinit var notifySwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(8, 8, 15))
        }
        scroll.addView(root)
        setContentView(scroll)

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }
        }
        val white = Color.WHITE
        val muted = Color.rgb(180, 175, 200)
        val purple = Color.rgb(183, 85, 255)
        root.addView(text("🛡  PopUpZero 👑", 28f, purple, true))
        root.addView(text("LIVE AD & TRACKER PROTECTION", 11f, muted, true))
        status = text("Protection is OFF", 19f, white, true)
        root.addView(status)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(25, 19, 38))
        }
        root.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 22 })
        card.addView(text("BLOCKED REQUESTS", 12f, muted, true))
        count = text("0", 48f, white, true)
        card.addView(count)
        card.addView(text("Requests blocked today on this device", 13f, muted))

        protectSwitch = Switch(this).apply {
            text = "Protect regular + incognito tabs"
            textSize = 16f
            setTextColor(white)
            isChecked = prefs.getBoolean("protection", false)
            setOnCheckedChangeListener { _, checked ->
                if (checked) requestVpn() else stopProtection()
            }
        }
        root.addView(protectSwitch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        root.addView(text(
            "Incognito note: Android's local VPN filter cannot tell normal tabs from incognito tabs. " +
            "When protection is enabled, the same domain filtering applies to both automatically.",
            12f, muted
        ))

        notifySwitch = Switch(this).apply {
            text = "Send 'Blocked Ad by PZ 👑' notifications"
            textSize = 14f
            setTextColor(white)
            isChecked = prefs.getBoolean("notifications", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("notifications", checked).apply()
            }
        }
        root.addView(notifySwitch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })

        root.addView(text("WHAT V1 BLOCKS", 13f, purple, true).apply {
            setPadding(0, 28, 0, 8)
        })
        root.addView(text(
            "• Known ad-serving domains\n• Known tracker domains\n• Some popup and redirect services\n\n" +
            "This is DNS-level filtering. It blocks matching domain lookups before the browser can connect, " +
            "but cannot reliably remove ads served from the same domain as page content or ads embedded directly in video.",
            13f, muted
        ))
        root.addView(text(
            "Privacy: filtering happens on this device. DNS lookups for allowed domains are forwarded to Cloudflare DNS over HTTPS. " +
            "No browsing history is stored or uploaded by this app.",
            12f, muted
        ).apply { setPadding(0, 20, 0, 8) })
    }

    private fun requestVpn() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            startActivityForResult(prepare, 77)
        } else {
            startProtection()
        }
    }

    @Deprecated("Activity result API kept minimal for V1 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) startProtection()
        else {
            protectSwitch.isChecked = false
            prefs.edit().putBoolean("protection", false).apply()
        }
    }

    private fun startProtection() {
        val intent = Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START)
        startForegroundService(intent)
        prefs.edit().putBoolean("protection", true).apply()
        refresh()
    }

    private fun stopProtection() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        prefs.edit().putBoolean("protection", false).apply()
        refresh()
    }

    private fun refresh() {
        val active = prefs.getBoolean("protection", false)
        status.text = if (active) "● PROTECTION ACTIVE" else "Protection is OFF"
        status.setTextColor(if (active) Color.rgb(45, 230, 145) else Color.WHITE)
        count.text = prefs.getLong("blocked", 0L).toString()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refresh()
    }
}
