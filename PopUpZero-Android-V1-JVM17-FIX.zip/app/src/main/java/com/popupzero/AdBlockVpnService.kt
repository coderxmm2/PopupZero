package com.popupzero

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AdBlockVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.popupzero.START"
        const val ACTION_STOP = "com.popupzero.STOP"
        private const val CHANNEL = "popupzero_protection"
        private const val DNS_IP = "10.0.0.2"
        private val BLOCKED_DOMAINS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "adsrvr.org", " taboola.com",
            "outbrain.com", "advertising.com", "adform.net", "scorecardresearch.com",
            "googletagmanager.com", "google-analytics.com", "connect.facebook.net",
            " branch.io", "app-measurement.com"
        ).map { it.trim() }.filter { it.isNotEmpty() }
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private val prefs by lazy { getSharedPreferences("pz", MODE_PRIVATE) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopFiltering()
            ACTION_START, null -> startFiltering()
        }
        return START_STICKY
    }

    private fun startFiltering() {
        if (running.get()) return
        createChannel()
        startForeground(1, buildNotification("Protection active"))
        try {
            val builder = Builder()
                .setSession("PopUpZero")
                .addAddress("10.0.0.1", 32)
                .addDnsServer(DNS_IP)
                .addRoute(DNS_IP, 32)
                .setMtu(1500)
            tun = builder.establish()
            if (tun == null) {
                stopSelf()
                return
            }
            running.set(true)
            thread(name = "PZ-DNS-filter") { packetLoop() }
        } catch (_: Exception) {
            running.set(false)
            stopSelf()
        }
    }

    private fun stopFiltering() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun packetLoop() {
        val fd = tun?.fileDescriptor ?: return
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val n = input.read(buffer)
                if (n <= 0) continue
                val packet = buffer.copyOf(n)
                val parsed = parseDnsPacket(packet) ?: continue
                val qname = parsed.qname.lowercase()
                val blocked = BLOCKED_DOMAINS.any { qname == it || qname.endsWith(".$it") }
                val dnsReply = if (blocked) {
                    incrementBlocked()
                    makeNxDomain(parsed.dns)
                } else {
                    queryCloudflare(parsed.dns) ?: continue
                }
                val responsePacket = buildIpv4UdpReply(packet, parsed, dnsReply) ?: continue
                output.write(responsePacket)
                if (blocked && prefs.getBoolean("notifications", false)) {
                    showBlockedNotification(qname)
                }
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private data class Parsed(val ipHeaderLen: Int, val udpOffset: Int, val dns: ByteArray, val qname: String,
                              val srcIp: ByteArray, val dstIp: ByteArray, val srcPort: Int, val dstPort: Int)

    private fun parseDnsPacket(p: ByteArray): Parsed? {
        if (p.size < 28 || (p[0].toInt() shr 4 and 0xF) != 4 || (p[9].toInt() and 0xFF) != 17) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p.size < ihl + 8 + 12) return null
        val udp = ihl
        val dstPort = u16(p, udp + 2)
        if (dstPort != 53) return null
        val dnsLen = u16(p, udp + 4) - 8
        if (dnsLen < 12 || p.size < udp + 8 + dnsLen) return null
        val dns = p.copyOfRange(udp + 8, udp + 8 + dnsLen)
        val qname = readQName(dns) ?: return null
        return Parsed(ihl, udp, dns, qname, p.copyOfRange(12, 16), p.copyOfRange(16, 20),
            u16(p, udp), dstPort)
    }

    private fun readQName(d: ByteArray): String? {
        if (d.size < 13) return null
        var i = 12
        val labels = mutableListOf<String>()
        while (i < d.size) {
            val len = d[i++].toInt() and 0xFF
            if (len == 0) break
            if (len > 63 || i + len > d.size) return null
            labels.add(String(d, i, len, Charsets.US_ASCII))
            i += len
        }
        return labels.takeIf { it.isNotEmpty() }?.joinToString(".")
    }

    private fun makeNxDomain(query: ByteArray): ByteArray {
        val r = query.copyOf()
        if (r.size >= 12) {
            val flags = u16(r, 2) or 0x8000 or 0x0080 or 0x0003
            put16(r, 2, flags)
            put16(r, 6, 0); put16(r, 8, 0); put16(r, 10, 0)
        }
        return r
    }

    private fun queryCloudflare(dns: ByteArray): ByteArray? {
        return try {
            val conn = URL("https://cloudflare-dns.com/dns-query").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/dns-message")
            conn.setRequestProperty("Accept", "application/dns-message")
            conn.outputStream.use { it.write(dns) }
            if (conn.responseCode != 200) null else conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) { null }
    }

    private fun buildIpv4UdpReply(original: ByteArray, p: Parsed, dns: ByteArray): ByteArray? {
        val ipLen = 20
        val udpLen = 8 + dns.size
        val total = ipLen + udpLen
        if (total > 65535) return null
        val out = ByteArray(total)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, 0)
        put16(out, 6, 0x4000)
        out[8] = 64
        out[9] = 17
        System.arraycopy(p.dstIp, 0, out, 12, 4)
        System.arraycopy(p.srcIp, 0, out, 16, 4)
        put16(out, 10, checksum(out, 0, 20))
        put16(out, 20, 53)
        put16(out, 22, p.srcPort)
        put16(out, 24, udpLen)
        put16(out, 26, 0)
        System.arraycopy(dns, 0, out, 28, dns.size)
        return out
    }

    private fun incrementBlocked() {
        val total = prefs.getLong("blocked", 0L) + 1
        prefs.edit().putLong("blocked", total).apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "PopUpZero protection", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("PopUpZero 👑")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    private fun showBlockedNotification(domain: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            buildNotification("Blocked Ad by PZ 👑 · $domain"))
    }

    private fun u16(b: ByteArray, i: Int): Int = ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)
    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v shr 8).toByte(); b[i + 1] = v.toByte()
    }
    private fun checksum(b: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            sum += (((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)).toLong()
            i += 2
        }
        if (i < offset + length) sum += ((b[i].toInt() and 255) shl 8).toLong()
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        return sum.inv().toInt() and 0xffff
    }

    override fun onDestroy() {
        stopFiltering()
        super.onDestroy()
    }
}
