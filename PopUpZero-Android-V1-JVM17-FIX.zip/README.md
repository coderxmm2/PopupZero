# PopUpZero Android V1

Native Android Kotlin project. V1 uses Android `VpnService` to route DNS lookups to a local DNS filter and forwards allowed DNS queries to Cloudflare DNS-over-HTTPS. Known advertising/tracking domains are answered with NXDOMAIN before the browser can connect.

## Incognito coverage
The DNS filter operates at device VPN/DNS level and does not inspect browser tabs or identify private mode. When enabled, it applies the same domain filtering to regular and incognito tabs in browsers that use Android's configured DNS path. The app cannot offer a separate incognito-only filter.

## Build
GitHub Actions workflow: `.github/workflows/build.yml`.
Push to `main` or manually run the workflow. Download the APK artifact from the completed Actions run.

## Limitations
- V1 is domain/DNS filtering, not a full cosmetic ad blocker.
- It cannot reliably block ads served from the same domain as page content, ads embedded directly in video streams, or content delivered through app-specific encrypted DNS that bypasses the system resolver.
- It does not read page contents, browser feeds, or browsing history.
- The VPN uses a DNS-only route, not a full-device traffic tunnel.
- This is an early MVP and should be tested on a spare/test device before relying on it.
- Cloudflare DNS-over-HTTPS is used for allowed lookups; this provider choice is visible in the source.
