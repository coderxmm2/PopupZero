# PopUpZero V1

A small Manifest V3 Chromium extension that blocks many script-triggered `window.open()` calls unless they follow a recent trusted user interaction. It also blocks synthetic clicks on `_blank` links and counts blocked attempts.

## Install in a desktop Chromium browser
1. Unzip the project.
2. Open the browser's extensions page.
3. Turn on Developer mode.
4. Choose **Load unpacked** and select the `extension` folder.

## Important limitations
- This is a basic V1, not a full ad blocker. It cannot guarantee that every popup, redirect, overlay, or ad will be blocked.
- It does not inspect browser traffic or delete ads already rendered in a page.
- Some legitimate sites may use delayed popups and may be affected.
- Browser internal pages, extension stores, and some protected pages do not allow content scripts.
- Android Chrome does not support installing ordinary desktop Chrome extensions. Use a compatible desktop Chromium browser or a mobile browser that explicitly supports extensions.

## GitHub Actions
The workflow in `.github/workflows/build.yml` packages the extension folder into a ZIP and uploads it as a downloadable workflow artifact.
