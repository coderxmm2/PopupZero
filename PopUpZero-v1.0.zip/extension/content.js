(() => {
  // Avoid installing twice in the same frame.
  if (window.__popupZeroInstalled) return;
  window.__popupZeroInstalled = true;

  const recordBlock = () => {
    try {
      chrome.runtime.sendMessage({ type: "POPUPZERO_BLOCKED" });
    } catch (_) {}
  };

  // Keep a short-lived record of direct user interaction. This lets ordinary
  // click-triggered links keep working while blocking delayed/scripted popups.
  let lastGesture = 0;
  const markGesture = (event) => {
    if (event.isTrusted) lastGesture = Date.now();
  };
  addEventListener("pointerdown", markGesture, true);
  addEventListener("keydown", markGesture, true);
  addEventListener("touchstart", markGesture, true);

  const nativeOpen = window.open.bind(window);
  window.open = function(url, target, features) {
    const recentUserGesture = Date.now() - lastGesture < 1200;
    if (!recentUserGesture) {
      recordBlock();
      return null;
    }
    return nativeOpen(url, target, features);
  };

  // Block common hidden/automatic target=_blank popup attempts. Links that
  // follow a real user click are left alone.
  document.addEventListener("click", (event) => {
    const link = event.target && event.target.closest
      ? event.target.closest("a[target='_blank'], area[target='_blank']")
      : null;
    if (!link) return;
    if (!event.isTrusted) {
      event.preventDefault();
      event.stopImmediatePropagation();
      recordBlock();
    }
  }, true);
})();