const count = document.getElementById("count");
function refresh() {
  chrome.storage.local.get({ blockedCount: 0 }, (data) => {
    count.textContent = String(data.blockedCount);
  });
}
refresh();
chrome.storage.onChanged.addListener(refresh);