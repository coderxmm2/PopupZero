chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "POPUPZERO_BLOCKED") return;

  chrome.storage.local.get({ blockedCount: 0 }, (data) => {
    chrome.storage.local.set({ blockedCount: data.blockedCount + 1 });
  });
});